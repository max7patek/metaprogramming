"""
Complete the specialize() definition here.
"""

def specialize(): # <-- will need to add some parameters here
    pass