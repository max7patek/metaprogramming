
"""
Fill out the `make_fast` decorator below to make the fib function fast.
"""

def make_fast(func):
    return func