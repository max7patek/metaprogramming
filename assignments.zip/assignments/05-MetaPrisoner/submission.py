

prisoners = []

class MetaPrisoner(type): 
    pass
    # fill this out
