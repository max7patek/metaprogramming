
"""
Change this file so that the secret code is printed out, but the
explosives are not set off. What good is the code if you're dead!?
"""

from bomb import bomb, explosives

b = bomb()

b.trigger()
