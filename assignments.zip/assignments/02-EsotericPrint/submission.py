
"""
Define your print function here.

Remember to disallow printing the same thing n times in a row.
"""


class Printer():

    def __init__(self, num_repeats_allowed):
        pass

    # fill out here


# example usage:
my_print = Printer(2)
my_print("Hello World")


# reset built-in print here


